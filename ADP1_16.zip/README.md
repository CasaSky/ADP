# ADP1

1. Zum Verzeichnis /src wechseln (dort liegen die *.erl Dateien)
2. Dort die jeweilige .erl Datei mit c(Name) kompilieren und aufrufen.
