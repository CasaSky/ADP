%%%-------------------------------------------------------------------
%%% @author talal
%%% @copyright (C) 2017, <COMPANY>
%%% @doc
%%%
%%% @end
%%% Created : 11. Apr 2017 20:03
%%%-------------------------------------------------------------------
-module(btree).
-author("talal").

%% API
-export([initBT/0, isBT/1, insertBT/2, isEmptyBT/1, equalBT/2]).

%initBT 0 -> btree
initBT() -> {}.

%isBT btree -> bool
isBT(Btree) -> isBT(Btree, 1, 100,0).

isBT({},_,_,_) -> true;
isBT({Elem,Accu,LBtree,RBtree},Accu,Max,Min) when (Elem<Max) and (Elem>Min) -> isBT(LBtree,Accu+1, Elem, Min) and isBT(RBtree,Accu+1,Max,Elem);
isBT(_,_,_,_) -> false.

%insertBT: btree x elem -> btree
insertBT({},Elem) -> {Elem,1,{},{}};
insertBT({KnotenElem,Hoehe,{},RBtree}, Elem) when KnotenElem > Elem -> {KnotenElem,Hoehe,{Elem,Hoehe+1,{},{}},RBtree};
insertBT({KnotenElem,Hoehe,LBtree,{}}, Elem) when KnotenElem < Elem -> {KnotenElem,Hoehe,LBtree,{Elem,Hoehe+1,{},{}}};

insertBT(Btree, Elem) -> {KnotenElem,Hoehe,LBtree,RBtree} = Btree,
  if KnotenElem > Elem -> {KnotenElem,Hoehe, insertBT(LBtree,Elem),RBtree};
    KnotenElem < Elem -> {KnotenElem,Hoehe, LBtree, insertBT(RBtree,Elem)};
    true -> Btree
  end.

%isEmptyBT: btree -> bool
isEmptyBT({}) -> true;
isEmptyBT(_) -> false.

%equalBT: btree x btree -> bool
equalBT(Btree,Btree) -> true;
equalBT(_,_) -> false.

